This virus is harmeless to your computer, You can run it on a real machine and it will shut down your computer.
This thing is harmeless BUT is considered a "Trojan" for me (Developer: Sync_tech)
But i don't damage any computer, or any Office computer, Is a virus considered a Trojan because YOU can
prank your friends with a fake virus.

Thanks for reading this.